gcc -dynamiclib functions.c -o libfunctions.dylib
