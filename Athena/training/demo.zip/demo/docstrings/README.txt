To generate HTML documentation for foo.py using epydoc, run

  epydoc -o foo_html --html foo.py

Open the file foo_html/index.html in your browser to see the documentation.
