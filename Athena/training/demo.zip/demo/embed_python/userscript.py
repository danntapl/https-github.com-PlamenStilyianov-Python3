
import math
import tools

print "*** Hello from {}! ***".format(__name__)

result = math.pi * tools.meaning() * tools.fact(4)
