
def simple_generator():
    print "first"
    yield 1
    print "second"
    yield 2

