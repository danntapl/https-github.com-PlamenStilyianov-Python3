import example

print 'factorial of 10:', example.fact(10)