#include <math.h>

double my_hypot(double a, double b)
{
    return sqrt(a*a+b*b);
}
    