#ifndef HYPOT_H
#define HYPOT_H

double my_hypot(double a, double b);

#endif