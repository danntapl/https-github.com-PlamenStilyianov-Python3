
int nan_to_zero_double(int len, double *array);
int nan_to_zero_float(int len, float *array);
