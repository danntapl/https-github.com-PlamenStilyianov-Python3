Run demo.py from within ipython.
