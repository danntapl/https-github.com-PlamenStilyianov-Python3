These are from the scikits-image web page:
    plot_canny.py
    plot_hough_transform.py
    plot_lena_tv_denoise.py
    plot_watershed.py

demo/ contains a Traits+Chaco app that demonstrate the skimage
canny edge detector and probablilistic Hough transform.  The
file dc_metro.JPG from the numpy plotting exercise is a nice
image to use in this demo.  To run the demo:
$ cd demo
$ python chaco_image_demo.py
