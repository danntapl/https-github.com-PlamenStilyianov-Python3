# foo.py
""" Short docstring for the module goes here.

    A longer description for the module goes it here.  It
    is typically multiple lines long.
"""

class Foo(object):
    """ Short docstring for Foo class.
    
        Longer docstring describing the Foo class.
    """
    
    def some_method(self):
        """ short description for some_method.
        
            longer description for some_method...
        """    
        

def bar():
    """ Short docstring for bar method.
    
        And, suprisingly, the long description for the 
        method.
    """        
