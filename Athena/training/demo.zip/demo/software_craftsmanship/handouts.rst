Software Craftsmanship
======================

.. toctree::

   handouts/coding_standard
   handouts/function_design
   
