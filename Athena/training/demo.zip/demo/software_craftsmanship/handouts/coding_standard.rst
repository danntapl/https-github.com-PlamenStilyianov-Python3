Coding Standard
---------------

.. literalinclude:: coding_standard.py


