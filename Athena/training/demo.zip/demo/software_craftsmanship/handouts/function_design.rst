Function Design
---------------

Single Function
~~~~~~~~~~~~~~~

.. literalinclude:: function_design/single_function.py


Factored Function
~~~~~~~~~~~~~~~~~

.. literalinclude:: function_design/factored_function.py

