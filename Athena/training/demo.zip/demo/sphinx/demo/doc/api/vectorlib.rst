vectorlib Package
=================

:mod:`util` Module
------------------

.. automodule:: vectorlib.util
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`vector` Module
--------------------

.. automodule:: vectorlib.vector
    :members:
    :undoc-members:
    :show-inheritance:

