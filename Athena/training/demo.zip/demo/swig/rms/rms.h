#ifndef RMS_H
#define RMS_H

double rms(double* seq, int n);

#endif
