
#ifndef VECT_H
#define VECT_H

int *vect(int x, int y, int z);
int sum(int *vector);

#endif
