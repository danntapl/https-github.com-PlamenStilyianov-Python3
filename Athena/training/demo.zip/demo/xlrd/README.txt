The Excel spreadsheet was downloaded from the "Human Development Reports"
section of the United Nations Development Programme (UNDP) web site:

    http://hdr.undp.org/en/statistics/hdi/
